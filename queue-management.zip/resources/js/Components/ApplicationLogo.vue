<template>
    <img class="" src="/images/latestlogo.png" alt="">
</template>
